###########Multivariate emulator for floc data
library(MASS)
library(MASS)
library(Matrix)
library(emulator)
library(multivator)
library(abind)
#set.seed(1)
setwd("./DATA_PAPER/Multivariate_Floc")
dirname=getwd()
##load the scaled inputs between[0,1]
X=read.csv("X.csv")## matrix of inputs
Y=read.csv("Y.csv")##load the matrix of logarithms of output data
X=as.matrix(X)
Y=as.matrix(Y)
###########################################EMULATOR FITTING
## model matrix
form= ~1 + y4 + y3 + y2 + y1 + nh4 + no3 + no2 + o2 + s + etaHET + MumHET + KsHET
H<-model.matrix(form,data=as.data.frame(X))
## Define number of columns of output and model matrices
k<-dim(Y)[2]
m<-dim(H)[2]
ninp=dim(X)[2]
############## Function giving the log marginal likelihood
tau=1
likfun2<-function(theta){
R=corr.matrix(X,scales=theta[-13])#corr matrix for output#2
A=R+(theta[13]*diag(tau,dim(R)))##add random nugget/noise
if(any(Re(eigen(A,TRUE,TRUE)$values) < 0)){
A=as.matrix(nearPD(A)$mat)
} else {
A=A
}
Omega=quad.form.inv(A,H)#t(H)%*%Ainv%*%H
dA=(determinant(A)$modulus[1])###return log ofdeterminant
dOmega=(determinant(Omega)$modulus[1])##return log of determinant
sig=(quad.form.inv(A,Y) - quad.form(quad.form.inv(quad.form.inv(A,H),t(solve(A,H))), Y))
S=determinant(sig)$modulus[1]
-0.5*k*dA-0.5*k*dOmega-.5*(n-m)*S
}
#########initialize the parameter values
initial_scale=rep(2,(ninp+1))#theta
lower=rep(1e-5,length(initial_scale))
upper=2*(apply(X,2,max)-apply(X,2,min))
opt<-optim(fn=likfun2,par=initial_scale,method="L-BFGS-B",control=list(fnscale= -1,trace=3),lower=lower,upper=upper)
save(opt,file=paste(getwd(),"opt",sep="/"))
R=corr.matrix(X,scales=opt$par[-13])#corr matrix for output#2
A=R+(opt$par[13]*diag(tau,dim(R)))
if(class(try(chol(A), silent = T)) == "try-error") # positive definite
{A=as.matrix(nearPD(A)$mat)
Ainv=chol2inv(chol(A))###
} else {
Ainv=chol2inv(chol(A))###
}
model=list(X=X,Y=Y,theta=opt$par,form=form,Ainv=Ainv,nam=nam)
dirname=getwd()
save(model,file=paste(dirname,"model",sep="/"))###spa
##########################PREDICTION FUNCTIONS
pred=function(model,newdata){	
X<- model$X
Y<- model$Y
theta1=model$theta[13]
theta<- model$theta[-13]
form<- model$form
Ainv<- model$Ainv
A=solve(Ainv)
n2<- dim(newdata)[1]
n<- dim(X)[1]
X0<- newdata
colnames(X0)=model$nam
######model matrix 
H<-model.matrix(form,data=as.data.frame(X))
H0<-model.matrix(form,as.data.frame(X0))
A01=corr.matrix(X0,X,scales=theta)###cross correlation
A00=corr.matrix(X0,X0,scales=theta)##test point correlation
A00=A00
Omega=quad.form.inv(A,H)#t(H)%*%Ainv%*%H
betahat=solve(Omega,crossprod(H, solve(A, Y)))##betahat=ginv(t(H)%*%Ainv%*%H)%*%(t(H)%*%Ainv%*%Y)
mu_star=(H0%*%betahat)+crossprod(A01,Ainv)%*%(Y-H%*%betahat)#H0%*%betahat+t(A01)%*%Ainv%*%(Y-H%*%betahat)
c_star=A00-(t(A01)%*%Ainv%*%A01)+(((H0-(t(A01)%*%Ainv%*%H))%*%solve(Omega)%*%t(H0-(t(A01)%*%Ainv%*%H))))
Sigma=(t(Y-H%*%betahat)%*%Ainv%*%(Y-H%*%betahat))/(n-m)
#######Predictive variance per output
if(class(try(chol(c_star), silent = T)) == "try-error") # positive definite
{c_star=as.matrix(nearPD(c_star)$mat)
} else {
c_star=c_star###
}
svar=list()
for(i in 1:n2){
svar[[i]]=(diag(c_star)[i]*diag(Sigma))
}
K0=abind(svar,along=2)
out=list(mu=mu_star,K=t(K0))
return(out)
}
##########Validation results
nout=4
nres=20##number of validation results
load("model")###R object
##load the matrix of logarithms of the 20 validation datasets
val=list()
out=list()
for(k in 1:nres){
val[[k]]=read.csv(paste(sub("k",k,"Y_k.csv"),sep="/"))
}
for(k in 1:nres){
inp=as.matrix(read.csv("XX.csv"))###matrix of input parameters
ini=as.matrix(read.csv("XX_ini.csv"))##matrix of initial parameters
input=matrix(c(inp[k,],ini[k,]),nrow=1)
colnames(input)=c("KsHET","MumHET","etaHET","s","o2","no2","no3","nh4","y1","y2","y3","y4")
##iterative use of emulator (dynamically)
nsim=200##number of Monte carlo simulation
npoints=1#number of points to predict per time point
mstar=list();result=list();mstar2=list()
sims=matrix(NA,nrow=npoints,ncol=nsim)
j=1
m1=pred(model,newdata=input)
mu=m1$mu###predictions
varr=m1$K#variance
mstar=mvrnorm(nsim,c(mu),diag(c(varr),ncol=nout,nrow=nout))
V1=varr
V2=0
mstar2[[j]]=mstar
result[[j]]=cbind(mu,V1+V2)
ntime=dim(val[[k]])[1]

for(j in 2:ntime){
g2a=mstar2[[j-1]]
inp2=matrix(rep(inp[k,],nsim),nrow=nsim,byrow=TRUE)
input=cbind(inp2,g2a)
colnames(input)=c("KsHET","MumHET","etaHET","s","o2","no2","no3","nh4","y1","y2","y3","y4")
m1=pred(model,newdata=input)
p1=array(m1$mu,c(npoints,nsim,nout))
p2=array(m1$K,c(npoints,nsim,nout))
mu=t(matrix(apply(p1,3,rowMeans)))
mu2=array(rep(mu,nsim),c(npoints,nout,nsim));mu2=aperm(mu2,c(1,3,2))
varr=apply(p2,c(1,3),mean)#expectation of variance
varr2=apply((p1-mu2)^2,3,rowMeans)#variance of expectation
V1=varr;V2=varr2
mstar=mvrnorm(nsim,c(mu),diag(c(V1+V2),ncol=nout,nrow=nout))
mstar2[[j]]=mstar
result[[j]]=cbind(mu,V1+V2)
}
res=abind(result,along=1)
emu=res[,1:4]
vv=res[,5:8]
out[[k]]=list(emu,vv)
}
#Compute the multivariate Proportion of variance (P) and Root Mean squared Error (RMSE) Table 1
vv2=list()
for(k in 1:20){
vv2[[k]]=out[[k]][[1]]###emulator
}
lammp=abind(val,along=1)
emu=abind(vv2,along=1)
P=rep(NA,nout)
RMSE=P
for(i in 1:nout){
P[i]=1-(sum((lammp[,i]-emu[,i])^2)/sum((lammp[,i]- mean(lammp[,1]))^2))##propotion
RMSE[i]=sqrt(mean((lammp[,i]-emu[,i])^2))##RMSE
}
P
RMSE
###############################################################PLOTS
##FIGURE 7 IN THE MANUSCRIPTS
k=10
emu2=out[[k]][[1]]###emulator
vv=out[[k]][[2]]###emulator variance
lammp=val[[k]]####LAMMPS simulated values
ntime2=nrow(lammp)
dev=sqrt(vv)
tit=c(expression("Floc eqv. diameter"),"Fractal dimension","No of particle",expression("Floc total mass"~(gram)))
pow=c(1,1,1,1)
dirn3=sub("k",k,paste("Density","k",sep="_"))
dir.create(dirn3)
dirn=paste(getwd(),dirn3,sep="/")

pos=c("topleft","topright","topleft","topleft")
for(i in 1:(nout)){
dirname=file.path(dirn,paste(paste(dirn3,"_"),i,".jpeg",sep=""))
jpeg(file=dirname,quality=100)
bw=c(.6,0.20,.6,.4)
bw=bw[i]
lammps=(lammp[,i]*pow[i])
emu=(emu2[,i]*pow[i])
d1=density(lammps,bw=bw)
d0=density(emu,bw=bw)
sd=(dev[,i]*pow[i])
h1=density(emu+(2*sd),bw=bw)
h2=density(emu-(2*sd),bw=bw)
x1=min(d0$x,d1$x,h1$x,h2$x)
x2 = max(d0$x,d1$x,h1$x,h2$x)
y1 = min(d0$y,d1$y,h1$y,h2$y)
y2 = max(d0$y,d1$y,h1$y,h2$y)
plot(d1,main=tit[i],xlab="",cex.lab=1.5,cex.axis=1.6,cex.main=1.7,ylim=c(y1,y2)+c(0,0),xlim=c(x1,x2))
lines(d0,col="green")
lines(d0$x,h1$y, col="red",lwd=3,lty=2)
lines(d0$x,h2$y, col="red",lwd=3,lty=2)
legend(pos[i],c("Predicted","Observed","95% C.I"),
fill=c("green","black","red"),bty="0",border="black",cex=1.75,horiz=FALSE)

dev.off()
}
##FIGURE 6 IN THE MANUSCRIPTS
k=10
emu2=out[[k]][[1]]###emulator
vv=out[[k]][[2]]###emulator variance
lammp=val[[k]]####LAMMPS simulated values
ntime2=nrow(lammp)
dev=sqrt(vv)
dirn2=sub("k",k,paste("Linear","k",sep="_"))
tit=c(expression("Floc eqv. diameter"),"Fractal dimension","No of particle",expression("Floc total mass"~(gram)))
dir.create(dirn2)
dirn=paste(getwd(),dirn2,sep="/")
for(i in 1:(nout)){
dirname=file.path(dirn,paste(paste(dirn2,"_"),i,".jpeg",sep=""))
jpeg(file=dirname,quality=100)
mytitle=tit[i]
lammps=lammp[,i]*pow[i]
emu=emu2[,i]*pow[i]
sd=dev[,i]*pow[i]

U=emu+(2*sd)
L=emu-(2*sd)
time=(1:ntime2)*10^4/(24*60*60)###days
x1 = min(U,lammps,emu,L)
x2 = max(U,lammps,emu,L)
par(mar=c(5.1,5.4,4.1,2.1))
plot(time,lammps,main=mytitle,ylab=expression("Output"),lty=1,col="black",xlab="time (day)",cex.lab=1.7,cex.axis=1.7,cex.main=1.7,xlim=range(time),ylim=c(x1,x2)+c(0,.03))
lines(time,L, col="red",lwd=3,lty=2)
lines(time,U, col="red",lwd=3,lty=2)
lines(time,emu,col="green",lwd=3)
legend(1,(x2+.03),c("Predicted","Observed","95% C.I"),fill=c("green","black","red"),bty="0",border="black",cex=1.75,horiz=FALSE)
dev.off()
}
