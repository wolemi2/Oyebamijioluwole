Gaussian process emulation of an individual-based model simulation of microbial communities
O.K. Oyebamiji, D.J. Wilkinson, P.G. Jayathilake, T.P. Curtis, S.P. Rushton, B. Lie, P. Gupta
This folder contains data and code to reproduce results in the manuscripts. There are 4 subfolders namely:
(i) Multivariate_Floc - This subfolder contains the data and code for fitting the multivariate emulator for the floc and generating Figures 6 & 7 and (/rho and RMSE multivariate portion  Table 1) in the manuscript.
(a) code1.R R functions for fitting emulator and performing crossvalidation for mutivariate floc emulation
(b) X.csv - A 2000 X 12 matrix of sampled input parameters (floc training data)
(c) Y.csv - A 2000 X 4 matrix of sampled characterized outputs  (floc training data)
(d) XX.csv - A 20 X 8 matrix of input parameters for 20 validation points (floc test data)
(e) XX_ini.csv - A 20 X 4 matrix of initial input parameters for 20 validation points (floc test data)
(f) (Y_1.csv -Y_20.csv) -  Each is a matrix of 4 simulated outputs of varying dimension for 20 different validation points (floc test data). 
(ii) Multivariate_Biofilms - This folder contain the data and code for fitting the
 multivariate emulator for the biofilms and generating Figures 8 & 9  and (/rho and RMSE multivariate portion Table 1) in the manuscript.
(a) code3.R - R functions for fitting emulator and performing crossvalidation for mutivariate biofilms emulation
(b) X.csv - A 1500 X 12 matrix of sampled input parameters (biofilms training data)
(c) Y.csv - A 1500 X 4 matrix of sampled characterized outputs  (biofilms training data)
(d) XX.csv - A 20 X 8 matrix of input parameters for 20 validation points (biofilms test data)
(e) XX_ini.csv - A 20 X 4 matrix of initial input parameters for 20 validation points (biofilms test data)
(f) (Y_1.csv -Y_20.csv) -  Each is a matrix of 4 simulated outputs of varying dimension for 20 different validation points (biofilms  test data). 
(iii) Univariate_Floc - This folder contain the data and code for fitting the univariate emulator for the floc and (/rho and RMSE of univariate portion Table 1) in the manuscript.
(a) code2.R - R functions for fitting emulator, performing sensitivity analysis and crossvalidation of univariate floc emulation and plotting Histograms in Figure 3
(b) X.csv - A 2000 X 36 matrix of sampled input parameters ie (32 parameters +4 initial values)  (floc training data)
(c) Y.csv - A 2000 X 4 matrix of sampled characterized outputs  (floc training data)
(d) XX.csv - A 20 X 32 matrix of input parameters for 20 validation points (floc test data)
(e) All_Floc.csv - A 17309 X 4 matrix containing all the 4 simulated floc outputs data before sampling
(iv) Univariate_Biofilms - This folder contain the data and code for fitting the univariate emulator for the biofilms
(a) code4.R - R functions for fitting emulator, performing sensitivity analysis and crossvalidation of univariate biofilms emulation and plotting Histograms in Figure 4
(b) X.csv - A 1500 X 36 matrix of sampled input parameters ie (32 parameters +4 initial values)  (biofilms training data)
(c) Y.csv - A 1500 X 4 matrix of sampled characterized outputs  (biofilms training data)
(d) XX.csv - A 20 X 32 matrix of input parameters for 20 validation points (biofilms test data)
(e) All_Biofilms.csv - A 3780 X 4 matrix containing all the 4 simulated biofilms outputs data before sampling.
Others:
Sensitivity.R - R codes for generating the plot of sentivity indices in Figure 10.
NOTE: Figures 1, 2 and 5 in the manuscripts are made outside R.
###################################################################
Dr. O.K. Oyebamiji
School of Mathematics & Statistics
Newcastle University
Newcastle upon Tyne
NE1 7RU
UK
E-mail: wolemi2@yahoo.com; Oluwole.Oyebamiji@ncl.ac.uk